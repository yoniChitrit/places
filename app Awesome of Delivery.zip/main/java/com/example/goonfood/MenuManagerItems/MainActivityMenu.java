package com.example.goonfood.MenuManagerItems;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.goonfood.DownloadTask;
import com.example.goonfood.FirstFragment.PropertyFirstFragment;
import com.example.goonfood.R;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import static com.example.goonfood.FirstFragment.FirstFragment.DATA_TRANSFER_MENU;
import static com.example.goonfood.Search.Search.DATA_TRANSFER_SEARCH;
import static com.example.goonfood.MenuManagerItems.ManagerListOfAdapterMenue.setView_user_selected_for_menu;
import static com.example.goonfood.MenuManagerItems.ManagerListOfAdapterMenue.setmData_PAY_ATTENTION_LayoutInflater_in_index_2;
import static com.example.goonfood.MenuManagerItems.ManagerListOfAdapterMenue.setmData_all_Items_LayoutInflater_in_index_after_title;
import static com.example.goonfood.MenuManagerItems.ManagerListOfAdapterMenue.setmData_mMy_Recent_Order_LayoutInflater_in_index_1;

   /*  recyclerView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                Log.e(TAG, "onGlobalLayout()");
                recyclerView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            }
        });*/

public class MainActivityMenu extends AppCompatActivity implements DownloadTask.DownloadComplete {
    private final static String TAG = "MainActivityMenu";
    private final static String OpenRestaurant = "Close 12 pm - Open 11:00";
    private final static String NameRestaurantForInputRightData = "Restauran";
    private final static int NumItemsTotalToRestaurant = 20;

    private Context context;

    // private RecyclerViewReadyCallback recyclerViewReadyCallback;
    /// private static ManagerListOfAdapterMenue managerListOfAdapterMenue;
    //private static PropertyMenu propertyMenu;

   // private static int i_ = 0;
    private static HashMap< Integer, String > myListV;
    private static int CountItemMenu=0;


    private ImageView ImgRestaurants=null;
    private ActionBar actionBar;
    private RecyclerView recyclerView=null;
    public AdapterMenu mAdapterMenu;
    private ArrayList< PropertyMenu > mDataMenu= new ArrayList<>();;
    private PropertyFirstFragment mDataFirsFragment;


    private static int IndexThatUserOpenNow;
    private Button ButtonToOrder_For_MainActivityMenu;
    private HashMap< Integer,Integer  > ShowToUserWhatSelected_;
    private HashMap< Integer, String > setIndexAndNameItem;
    //////---
    private ArrayList< String > valueBottom = new ArrayList<>();

  //  private HashMap< Integer, ArrayList< String > > ValueBottomHasMap;
    private static PropertyMenu menu_item_Back_Source;
//--------------------------------------keep on the value

    private View BottomSheet_;
    private LinearLayout mLinearLayout_;

    private HashMap<Integer, JSONArray> HoldKeyAndArrayOfRadioButton=new HashMap<>();

/*
   getButtonToOrder_For_MainActivityMenu().setBackgroundColor(Color.parseColor("#E12A1947"));
        if( getButtonToOrder_For_MainActivityMenu().getVisibility()==View.VISIBLE){
            getButtonToOrder_For_MainActivityMenu().setVisibility(View.INVISIBLE);
        }

*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_activity_0123);
        Log.e(TAG, "onCreate  ");
        context = this.getApplicationContext();   // getApplicationContext();

        ButtonToOrder_For_MainActivityMenu = (Button) findViewById(R.id.ButtonToOrder);
        ButtonToOrder_For_MainActivityMenu.setBackgroundColor(Color.parseColor("#E12A1947"));
        if (ButtonToOrder_For_MainActivityMenu.getVisibility() == View.VISIBLE) {
            ButtonToOrder_For_MainActivityMenu.setVisibility(View.INVISIBLE);
        }
        //  ButtonToOrder_For_MainActivityMenu.setVisibility(View.INVISIBLE);//WHEN CLICK TO RIGHT TO ORDER IT BECOME TO VISIBLE

        CreateBar();
        createListMenu();//create ref not chenge loction
// get data for first fragment
        Intent intent = getIntent();// just data for index 0 in the list need to sdd clock time in the json of firstFragment
        PropertyFirstFragment dataFirstFragment_Search = (PropertyFirstFragment) intent.getSerializableExtra(DATA_TRANSFER_SEARCH);
        PropertyFirstFragment dataFirstFragment = (PropertyFirstFragment) intent.getSerializableExtra(DATA_TRANSFER_MENU);
        if (dataFirstFragment != null) {
            //   Log.e(TAG,"71");

                mDataFirsFragment = dataFirstFragment;
                buildRecyclerView();


        } else {
            if (dataFirstFragment_Search != null) {
                //   Log.e(TAG, "DATA_TRANSFER_SEARC" + dataFirstFragment_Search.getmNameRestaurnt());

                    mDataFirsFragment = dataFirstFragment_Search;
                    buildRecyclerView();


            }

        }


    }
    private void createListMenu() {
        //  Log.e(TAG,"createListMenu() 175 line");

        recyclerView = findViewById(R.id.aRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        mAdapterMenu = new AdapterMenu(this, new ArrayList<>(), this);
        recyclerView.setAdapter(mAdapterMenu);
        mDataMenu = new ArrayList<>();

        myListV = new HashMap<>();//organizer the list by index i activates about its
        ShowToUserWhatSelected_ = new HashMap<>();//keep selects of user or some change that made

        setIndexAndNameItem = new HashMap<>();
        myListV.clear();
        mDataMenu.clear();
        setIndexAndNameItem.clear();
        ShowToUserWhatSelected_.clear();
        CountItemMenu=0;

      //  BottomSheetCreat();

    }

    private void CreateBar() {
        actionBar = getSupportActionBar();
        ImgRestaurants = (ImageView) findViewById(R.id.menuImageFoodTop);
        if (actionBar == null) {
            Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);

            if (toolbar != null) {
                setSupportActionBar(toolbar);
                actionBar = getSupportActionBar();

            }
        }
        if (actionBar != null) {
            //actionBar.setTitle("hii");
            Objects.requireNonNull(actionBar).setDisplayHomeAsUpEnabled(true);
        }
    }
    private void buildRecyclerView() {
        if (Objects.requireNonNull(mDataFirsFragment).getmImageRestaurnt() != null && actionBar != null) {
            // String imgUrl=dataRestaurants.getmImage();
            actionBar.setTitle(mDataFirsFragment.getmNameRestaurnt());
            Picasso.get().load(mDataFirsFragment.getmImageRestaurnt()).error(R.drawable.common_full_open_on_phone).placeholder(R.drawable.common_full_open_on_phone).into(ImgRestaurants);//holder.circleimageView

            DownloadTaskByTags();
        }

    }

    private void DownloadTaskByTags() {

        DownloadTask downloadTask = new DownloadTask(context, this);//DownloadTask.DownloadComplete
        Log.e(TAG, "line 163 startDownload :");
        //  progressBar_.setVisibility(View.VISIBLE);
        // String[] result=TagId[1].split(" ");

        String nameJson = mDataFirsFragment.getmTagsLink();
        Log.e(TAG, "line 196 --------------" + nameJson + ".json");
        String urlString = "https://yonichitrit.github.io/places/" + nameJson + ".json";

      //  Log.e(TAG, "urlString line 196 --------------  " + urlString);
        downloadTask.execute(urlString);
    }

    @Override
    public void onDownloadComplete(String result) {
       // Log.e(TAG, "line 168  " + result);
        if (result != null) {


            try {
                jsonData(result);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        //createListFromReferenceFirstActivity();
    }

    private void jsonData(String result) throws JSONException {
        createTheListItemMenuIndex0();//  index 0 to list from firstFragment

        JSONObject Response = new JSONObject(result);
        JSONArray ItemMenu = Response.getJSONArray("items");
         Log.e(TAG,"array json is  = "+ItemMenu.length());
        for (int i = 0; i < ItemMenu.length(); i++) {//jsonArray.length()
           // String category = "";
            JSONObject DataItems = ItemMenu.getJSONObject(i);

            if (DataItems.has("category")&& !DataItems.isNull("category")) {//DataItems.isNull("category")
                  String category = DataItems.getString("category");
                CategoryItemMenu(category);
            } else {

                String imageItem = DataItems.getString("image");
                String NameItem = DataItems.getString("name");
                String DescriptionItem = DataItems.getString("description");
                String meal_priceItem = DataItems.getString("meal_price");
                boolean availableItem = DataItems.getBoolean("available");
                boolean popular_itemItem = DataItems.getBoolean("popular_item");
                int TagsItem = DataItems.getInt("tags");


               if(DataItems.has("checkbox")&& !DataItems.isNull("checkbox")) {
                   JSONArray CheckBox = DataItems.getJSONArray("checkbox");
                   for (int j = 0; j < CheckBox.length(); j++) {//  inside all the value of this item
                      // Log.w(TAG,"size checkbox: "+CheckBox.toString());
                       HoldKeyAndArrayOfRadioButton.put(TagsItem,CheckBox);
                   //  createHasMapToChooseUser(CheckBox,TagsItem);

                   }
               }

                PropertyMenu menu_data = new PropertyMenu(imageItem, NameItem
                        , DescriptionItem, meal_priceItem, mDataFirsFragment.getmBlurhash(),
                        availableItem, popular_itemItem, "", TagsItem);//Marquee item =x1
                mDataMenu.add(menu_data);
                myListV.put(CountItemMenu, "after_index_0");
                CountItemMenu++;
            }//menu_data.getmTagsItem() it for to knew all the the change about it


            //  setmData_Restaurants_LayoutInflater_in_index_0(true);

        }  //close json
        if(mDataMenu.size()!=0) {
            mAdapterMenu.loadNewData(mDataMenu, myListV);//mAdapter reference to class and holder the data
            recyclerView.setAdapter(mAdapterMenu);
        }
    }
    private HashMap<String, String> createHasMapToChooseUser(JSONArray CheckBox,int tags){
      Log.e(TAG,"SIZE CHECKBOX: "+CheckBox.length()+" tagItem= "+tags);
        String[] ResultSplit; //new String[0];
        String[] SplitMoney;
        HashMap<String, String> hashMapOfRadioButton = new HashMap<>();
        try {

            for (int i=0;i<CheckBox.length();i++) {//size of array topping same need to check the botton
                JSONObject DataItemsArray = CheckBox.getJSONObject(i);
                ResultSplit = DataItemsArray.toString(i).split(":");
                String nameInTextView=ResultSplit[0];
                Log.e(TAG, "name TextView------------>" + nameInTextView);

               String[] nameValueInBottomSheet=ResultSplit[1].split(",");
                for(int j=0;j<nameValueInBottomSheet.length;j++) {
                    SplitMoney=nameValueInBottomSheet[j].split("=");// if you get index 0 and 1
                    Log.e(TAG,"size SplitMoney: "+SplitMoney.length);
                    if(SplitMoney.length==1){// you jast topping free
                        Log.e(TAG, "value topping----------->" + nameValueInBottomSheet[j]);
                        hashMapOfRadioButton.put(nameInTextView,nameValueInBottomSheet[j]);
                    }else {// you topping with money
                        Log.e(TAG, "value topping----------->" + SplitMoney[0]+"  Money=  "+SplitMoney[1]);
                        hashMapOfRadioButton.put(nameInTextView,SplitMoney[0]+" "+SplitMoney[1]);
                    }
                  /*  for (int k=0;k<SplitMoney.length;k++) {
                        if(k==0) {
                            Log.e(TAG, "value topping----------->" + SplitMoney[k]);//{"Choose Side":"Chiken,beef +3,Tofu,shirmp +16,White Meat +6"}
                        }else {
                            Log.e(TAG, "value topping of money----------->" + SplitMoney[k]);
                        }
                    }*/
                }
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
return hashMapOfRadioButton;
    }

    private void createTheListItemMenuIndex0() {// index 0
        String ShowOpenClose = "";
        if (mDataFirsFragment.ismIsOpenOrClose()) {// come for firstFragment
            ShowOpenClose = "Open > Close: 23pm";
        } else {
            ShowOpenClose = "Close > Open: 10am";
        }
        myListV.put(CountItemMenu, "index_0");
        CountItemMenu++;
        //    Log.e(TAG,"333 -> I == "+i_+" IN "+ getmData_Restaurants_LayoutInflater_in_index_0());
        PropertyMenu info_restaurants = new PropertyMenu(mDataFirsFragment.getmNameRestaurnt(), mDataFirsFragment.getmDescription(),
                ShowOpenClose, mDataFirsFragment.getmFeedbackRestaurants(), mDataFirsFragment.ismIsOpenOrClose(), mDataFirsFragment.getmLocationTime());
        //  PropertyMenu( NameRestaurants,  description,  ClockRestaurantsOpen , FeedbackRestaurants,boolean IsCloseOrOpen, ArrivalTimeToDelivery)
        mDataMenu.add(info_restaurants);
    }

    private void CategoryItemMenu(String ct) {
        myListV.put(CountItemMenu, "Category");
        CountItemMenu++;
        //  Log.e(TAG, "387 title  -> I == " + i_ + " IN " + getmData_mProperty_Value_LayoutInflater_in_index_title());
        PropertyMenu info_titel = new PropertyMenu(ct);
        mDataMenu.add(info_titel);
    }

    public Button getButtonToOrder_For_MainActivityMenu() {
        return ButtonToOrder_For_MainActivityMenu;
    }



    @Override
    protected void onStart() {
        super.onStart();


    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop() :");
    }


     /*  recyclerView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {

                recyclerView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                Log.e(TAG," finish ");
               // setmData_all_Items_LayoutInflater_in_index_after_title(false);
               // setmData_Restaurants_LayoutInflater_in_index_0(false);
               // setmData_mProperty_Value_LayoutInflater_in_index_title(false);

            }
        });*/



    //------------------------
    private void BottomSheetCreat() {///the json put the value inside because it different between restaurant to restaurant
        //   TempKeepDataUser=new HashMap<>();
      //  BottomSheet_ = findViewById(R.id.BottonSheet);
      //  mLinearLayout_=findViewById(R.id.mLinearLayout);

    }

    private void ShowOption() {
      View  BottomSheet_ = findViewById(R.id.BottonSheet);
        BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.from(BottomSheet_);
        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
    }
    public void listenerToBottomSheet(){
        String[] valusRadioButton;
        mLinearLayout_=findViewById(R.id.mLinearLayout);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams((int)
                LinearLayoutCompat.LayoutParams.WRAP_CONTENT,(int) LinearLayoutCompat.LayoutParams.WRAP_CONTENT);
        params.leftMargin =50;
        params.topMargin = 100;

      RadioGroup  rg = new RadioGroup(this);
        rg.setOrientation(RadioGroup.VERTICAL);
        for(int i=0;i<1;i++){

          RadioButton  rb = new RadioButton(this);
            rb.setTextSize(30);
             //rb.setTextMetricsParams();
            rb.setText("name item: "+i);
            rg.addView(rb);// arr

            rg.setLayoutParams(params);
        }
        mLinearLayout_.addView(rg);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton radioButton = (RadioButton) findViewById(checkedId);
                Toast.makeText(getApplicationContext(),radioButton.getText(),Toast.LENGTH_LONG).show();
            }
        });
        ShowOption();

       }
//-------------------------------------


    public void payAttention() {//if  myRecentOrder exist than put it 2 index else 1 index== boolean
        setmData_PAY_ATTENTION_LayoutInflater_in_index_2(true);
        //  PropertyMenu info_titel = new PropertyMenu("Title Food");
        //  mDataMenu.add(1, info_titel);
        mAdapterMenu.notifyItemRangeInserted(2, 1);

    }

    public void myRecentOrder() {
        setmData_mMy_Recent_Order_LayoutInflater_in_index_1(true);
        //  mDataMenu.add(1, info_titel);
        mAdapterMenu.notifyItemRangeInserted(1, 1);
    }

    //  positionOnSwap
    public int positionOnSwap(PropertyMenu propertyMenuSwap, int swapIndex) {// put this data in the world end selected
        Log.e(TAG, " swap 262  " + swapIndex);


        if (swapIndex > 0) {//every time swap one time, check if  swap already
            IndexThatUserOpenNow = swapIndex;// this index affect on all Mtode
            menu_item_Back_Source = propertyMenuSwap;
            ManagerHasMap();
            mDataMenu.remove((swapIndex));// deleted source
            mAdapterMenu.notifyItemRangeRemoved((swapIndex), 1);
            try {
                Thread.sleep(100);

                Log.e(TAG, " swap 264    Item ? ->     " + String.valueOf(keepValueUserSelected()));
                setView_user_selected_for_menu(true);
                // keep the data of item clicked for send order
                PropertyMenu propertyMenuSelect = new PropertyMenu(String.valueOf(keepValueUserSelected()), menu_item_Back_Source.getmNameFoodMenu()
                        , menu_item_Back_Source.getmInfoFoodMenu(), menu_item_Back_Source.getmPriceFoodMenu(), menu_item_Back_Source.getmIsFoodPopularMenu(),
                        menu_item_Back_Source.getmImageMenu(), menu_item_Back_Source.getmBlurHashMenu(),
                        menu_item_Back_Source.ismIsAvailableItem(), menu_item_Back_Source.getmTagsItem());

                mDataMenu.add(IndexThatUserOpenNow, propertyMenuSelect);
                mAdapterMenu.notifyItemRangeInserted(IndexThatUserOpenNow, 1);//POSITION SELRCTED

            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        } else {
            Log.e(TAG, "not swap in this index 274 line, or swap open already");

        }
        if (HoldKeyAndArrayOfRadioButton.get(menu_item_Back_Source.getmTagsItem()) != null) {
            JSONArray jsonArray = HoldKeyAndArrayOfRadioButton.get(menu_item_Back_Source.getmTagsItem());
            if (jsonArray != null) {
                Log.e(TAG, " GET size json: " + jsonArray.length());
                return jsonArray.length();// give me the key i will give you the num of button need create  by object json i kept
            } else {
                return 0;
            }


        }
return 0;
    }



    private void removeSwap() {
        mDataMenu.remove(IndexThatUserOpenNow);
        mAdapterMenu.notifyItemRangeRemoved(IndexThatUserOpenNow, 1);

    }

    private void BackToSourceList() {
        //   PropertyMenu propertyMenu = mAdapterMenu.getmData(i);//bring thr index of list and up data and
        // propertyMenu.setmMarqueeItem_Menu(String.format("%s %s ", "x", ShowToUserWhatSelected_.get(i)));
        String resultCountItem = "";

        setmData_all_Items_LayoutInflater_in_index_after_title(true);
        if (!ShowToUserWhatSelected_.get(menu_item_Back_Source.getmTagsItem()).equals(0)) {// with the kay
            resultCountItem = String.format("%s %s ", "x", ShowToUserWhatSelected_.get(menu_item_Back_Source.getmTagsItem()));
        }
        PropertyMenu temp = new PropertyMenu(menu_item_Back_Source.getmImageMenu(), menu_item_Back_Source.getmNameFoodMenu()
                , menu_item_Back_Source.getmInfoFoodMenu(), menu_item_Back_Source.getmPriceFoodMenu(), menu_item_Back_Source.getmBlurHashMenu(),
                menu_item_Back_Source.ismIsAvailableItem(), menu_item_Back_Source.getmIsFoodPopularMenu(),
                resultCountItem, menu_item_Back_Source.getmTagsItem());

        mDataMenu.add(IndexThatUserOpenNow, temp);
        mAdapterMenu.notifyItemRangeInserted(IndexThatUserOpenNow, 1);//POSITION SELRCTED
        //   Log.e(TAG, "IndexOrder= " + i + " Amoust= " + ShowToUserWhatSelected_.get(i) + "    -----------------------------------\n");
    }

    public int UpDataNumItemsOrder(int amount) {//

        for (int key : ShowToUserWhatSelected_.keySet()) {
            if(key==menu_item_Back_Source.getmTagsItem()) {
                int counter = ShowToUserWhatSelected_.get(key);
                Log.e(TAG, "UpDataNumItemsOrder line 511 =" + counter);

                ShowToUserWhatSelected_.put(menu_item_Back_Source.getmTagsItem(), (amount + counter)); // (amount+counter));
                Log.e(TAG, "UpDataNumItemsOrder line 513 =" + ShowToUserWhatSelected_.get(key));
                return ShowToUserWhatSelected_.get(key);
            }
        }
        ShowToUserWhatSelected_.put(menu_item_Back_Source.getmTagsItem(), amount);// in the first time
         return ShowToUserWhatSelected_.get(menu_item_Back_Source.getmTagsItem());
    }

    public int keepValueUserSelected() {// bring the vakue befor
        int result = 0;
        for (int i : ShowToUserWhatSelected_.keySet()) {
            Log.e(TAG, "keepValuUserSelected " + i);
            if (i == menu_item_Back_Source.getmTagsItem()) {// bring the vakue befor
                Log.e(TAG, "keepValuUserSelected in  " + ShowToUserWhatSelected_.get(i));
                result = ShowToUserWhatSelected_.get(i);
                break;
            }
        }
        Log.e(TAG, "keepValuUserSelected in line 526 " + menu_item_Back_Source.getmTagsItem());
        return result;          //ShowToUserWhatSelected_.get(menu_item_Back_Source.getmTagsItem());
    }

    public void ShowToUserWhatSelected() {//if get the value from AdapterMenu fresh the list ans marked the item selected

        int ColorListener = ((ColorDrawable) getButtonToOrder_For_MainActivityMenu().getBackground()).getColor();
        removeSwap();//
        Log.e(TAG, "Can Order");

        try {
            Thread.sleep(100);
            //   ShowToUserWhatSelected_.put(menu_item_Back_Source.getmTagsItem(), amount);
            BackToSourceList();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
   // getButtonToOrder_For_MainActivityMenu().setBackgroundColor(Color.parseColor("#E12A1947"));
   if(getButtonToOrder_For_MainActivityMenu().getVisibility()==View.VISIBLE)
    {
        getButtonToOrder_For_MainActivityMenu().setVisibility(View.INVISIBLE);
    }
 //MarqueeItem_
}

private void ManagerHasMap(){

 /*   if(checkBox1Value.isChecked()) {
        checkBox1Value.toggle();
        checkBox1Value.setChecked(true);
    }
    if(checkBoxValue.isChecked()){
        checkBoxValue.toggle();
        checkBoxValue.setChecked(true);
    }
    if(checkBox2Value.isChecked()){
        checkBox2Value.toggle();
        checkBox2Value.setChecked(true);
    }*/

   // for(int i:setIndexAndNameItem.keySet()){

        if(setIndexAndNameItem.get(menu_item_Back_Source.getmTagsItem())!=null&&ShowToUserWhatSelected_.get(menu_item_Back_Source.getmTagsItem())!=null){
            // USER SAME LIST
            Log.e(TAG,"i= "+menu_item_Back_Source.getmTagsItem()+ " ManagerHasMap  USER SAME LIST "+setIndexAndNameItem.get(menu_item_Back_Source.getmTagsItem()));
        }else {// null
            ShowToUserWhatSelected_.put(menu_item_Back_Source.getmTagsItem(), (0));
            setIndexAndNameItem.put(menu_item_Back_Source.getmTagsItem(),menu_item_Back_Source.getmNameFoodMenu());
            Log.e(TAG,"i= "+menu_item_Back_Source.getmTagsItem()+ " ManagerHasMap "+setIndexAndNameItem.get(menu_item_Back_Source.getmTagsItem()));



      //  }

    }



    // ValueBottomHasMap.put(IndexThatUserOpenNow,valueBottom);
    // valueBottom.clear();
}



    class RemoveItemIfNotAvailable implements Runnable {
       // private final static String TAG = "RemoveItemIfNotAvailable";
        Handler handler = new Handler();

      private int count=0;
     private   int indexList=0;

        public RemoveItemIfNotAvailable(int index) {
            indexList=index;
        }

        @Override
        public void run() {
            Log.e(TAG, "run line 544 f ------------------------------"+indexList);
            count++;
           if(count==10){
               Log.e(TAG, "run line 546 f ------------------------------"+ indexList);
                mDataMenu.remove(indexList);
                mAdapterMenu.notifyItemRangeRemoved(indexList,1);

               // handler.removeCallbacks(RemoveItemIfNotAvailable.this);
                handler.removeCallbacks(this);
                return;

            }

            handler.postDelayed(this, (1000 ));


        }


    }


    }







