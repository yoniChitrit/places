package com.example.goonfood.FirstFragment;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.goonfood.DownloadTask;

import com.example.goonfood.MainActivity;
import com.example.goonfood.MenuManagerItems.MainActivityMenu;
import com.example.goonfood.R;
import com.example.goonfood.RecyclerItemClickListener;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;

import com.google.android.gms.maps.model.LatLng;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


import static com.google.maps.android.SphericalUtil.computeDistanceBetween;

public class FirstFragment  extends Fragment implements DownloadTask.DownloadComplete,
        RecyclerItemClickListener.OnRecylerClickListener
{//,LocationRetriever.FailureListener,LocationRetriever.SuccessListener,Thread.UncaughtExceptionHandler
    private FusedLocationProviderClient fusedLocationClient;
     private static LocationCallback locationCallback;
    private LocationRequest locationRequest;
    private static boolean IsGetContext=false;


    private ProgressBar progressBar_;

    private static final String TAG = "FirstFragment";
    public static final String DATA_TRANSFER_MENU = "DATA_TRANSFER";
    private static final LatLng PRIME_MERIDIAN = new LatLng(0, 0);//start with this
    private static LatLng initialLocation =  new LatLng(0, 0);
    private static LatLng currentLocation = new LatLng(0, 0);
    private static  double DistanceLegal=10000.0;
    // private static Boolean  Myprovider=false;
    private RecyclerView recyclerView;
    @SuppressLint("StaticFieldLeak")
    private Context context;
    private MyAdapter mAdapter;
    private static ArrayList<PropertyFirstFragment> mDataFirstFragment = new ArrayList<>();

    private static DataFirstFragment DataToShearch;// interface
    private static String ResultJson=null;

   // private RunForLocationFirst runForLocationFirst; run class


    public static void setMyAdapterData(DataFirstFragment myAdapterData) {
        DataToShearch= myAdapterData;
        //   Log.e(TAG, "setMyAdapterData line 60");
        if(DataToShearch!=null) {
            Log.e(TAG, "setMyAdapterData line 60 in "+mDataFirstFragment.size());

        }
    }



    @SuppressLint("ObsoleteSdkInt")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        Log.e(TAG, "onCreateView");
        return inflater.inflate(R.layout.activity_first_fragment, container, false);
    }

    //  layoutManager = new LinearLayoutManager(getContext(), RecyclerView.VERTICAL,false);//LinearLayoutManager.HORIZONTAL
    //  recyclerView.setLayoutManager(layoutManager);
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Log.e(TAG, "onViewCreated");
        context = view.getContext().getApplicationContext();

        progressBar_= view.findViewById(R.id.progressBar);
        recyclerView = view.findViewById(R.id.RecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(context));
        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(context, recyclerView, this));//event handler
        mAdapter = new MyAdapter(context, new ArrayList<>());
        recyclerView.setAdapter(mAdapter);


        fusedLocationClient = LocationServices.getFusedLocationProviderClient(context);
        Log.e(TAG, " onViewCreated: "+fusedLocationClient);
        locationRequest = LocationRequest.create();
        locationRequest.setInterval(100000);
        locationRequest.setFastestInterval(5000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        LocationUpdates();
        LocationCallback();




      //  setContextFirstFragment((DataFirstFragment)this);
        // LocationCheck();
        try {
            Thread.sleep(1000);
            DownloadTask downloadTask = new DownloadTask(context, this);//DownloadTask.DownloadComplete
            Log.e(TAG, "startDownload :-");
            progressBar_.setVisibility(View.VISIBLE);
            String urlString = " https://yonichitrit.github.io/places/main.json";
            downloadTask.execute(urlString);
            IsGetContext=true;// if on the starrt
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


    }


    @Override
    public void onDownloadComplete(String result) {
        ResultJson = result;// keep it for next time
        if (currentLocation.latitude != 0.0 && currentLocation.longitude != 0.0) {
            BringTheJson(result);//
            Log.d(TAG, "line 124 currentLocation is right  !!! "+currentLocation.latitude +","+ currentLocation.longitude);
        }else {
            try {
                Thread.sleep(1000);
                onDownloadComplete(ResultJson);
                Log.d(TAG, "line 124 currentLocation not get  == 0 !!!!!!!!!!!!"+currentLocation.latitude +","+ currentLocation.longitude);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
        //  Log.e(TAG, "onDownloadComplete:" +ResultJson );
    }

    @Override
    public void OnItemClick(View view, int position) {
        Log.d(TAG, "OnItemClick");
        //  Toast.makeText(getContext(), "normal tag  "+position, Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(getActivity(), MainActivityMenu.class);//RestaurantMenu.class
        intent.putExtra(DATA_TRANSFER_MENU, mAdapter.getmData(position));//REFERENCE FROM THE
        startActivity(intent);

    }

    @Override
    public void OnItemLongClick(View view, int position) {

        //Toast.makeText(getContext(), "long tag  "+ position, Toast.LENGTH_SHORT).show();

    }




   /* class RunForLocationFirst implements Runnable {
        Handler handler = new Handler();

        public RunForLocationFirst() {
        }
        @Override
        public void run() {

          //  LocationCheck();
            Log.e(TAG, "run line 200 f ---------------------------------------------" );
            handler.postDelayed(this, (1000 * 20));
        }
    }*/
    public FirstFragment(){}


    @Override
    public void onStart() {
        super.onStart();
        Log.e(TAG, "onStart()");
       // LocationCheck();

       // runForLocationFirst = new RunForLocationFirst();
      //  runForLocationFirst.run();
        if(currentLocation.latitude!=0 &&currentLocation.latitude!=0) {

            LocationUpdates();
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        Log.e(TAG, "onStop()");
       /// runForLocationFirst.handler.removeCallbacks(runForLocationFirst);
        fusedLocationClient.removeLocationUpdates(locationCallback);
    }


    @Override
    public void onResume() {
        super.onResume();
        Log.e(TAG, "onResume()");

        //  runForLocationFirst = new RunForLocationFirst();
        //    runForLocationFirst.run();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e(TAG, "onDestroy()");
       // runForLocationFirst.handler.removeCallbacks(runForLocationFirst);
        fusedLocationClient.removeLocationUpdates(locationCallback);
    }

    private void BringTheJson(String result){
        // currency  online  city tags
        ArrayList<PropertyFirstFragment>  mDataFirstFragmentTemp = new ArrayList<>();
        //  mDataFirstFragment=new ArrayList<>();
        Log.e(TAG," SIZE: "+mDataFirstFragment.size());
        try {
            Log.e(TAG, " line 200 BringTheJson() initialLocation= :" + initialLocation.latitude + "," + initialLocation.longitude+"\n"+
                    " line 201 BringTheJson() currentLocation= :" + currentLocation.latitude + "," + currentLocation.longitude);
            //  Log.e(TAG, " line 201 BringTheJson() currentLocation= :" + currentLocation.latitude + "," + currentLocation.longitude);


            //  CalculationtTimeDelivery calculationtTimeDelivery = new CalculationtTimeDelivery();

            JSONObject response = new JSONObject(result);
            JSONArray JsonArray = response.getJSONArray("restaurants");

            for (int i = 0; i < JsonArray.length(); i++) {//jsonArray.length()
                JSONObject data_restaurant = JsonArray.getJSONObject(i);
                String Blurhash = data_restaurant.getString("blurhash");
                String city = data_restaurant.getString("city");
                String image = data_restaurant.getString("image");
                JSONArray location = data_restaurant.getJSONArray("location");
                String name = data_restaurant.getString("name");
                boolean IsOpen=data_restaurant.getBoolean("online");
                String description = data_restaurant.getString("description");
                String delivery_price = data_restaurant.getString("delivery_price");

                JSONArray tags_id = data_restaurant.getJSONArray("tags");



                // textView.append(  + "\n\n");
                double lan = location.getDouble(0);
                double lon = location.getDouble(1);
                String tagsIdSearch=tags_id.getString(0);
                String tagsIdAsLink=tags_id.getString(1);



                //   String tagsResult=String.format("%s,%s",tagsIdSearch,tagsIdAsLink);
                //    String[] resultSplit = tagsResult.split(",");
                // Log.e(TAG, "my location from:" + currentLocation.latitude+""+currentLocation.longitude);
                //   Log.e(TAG, "tags restaurants: -----------------" +resultSplit[0]+"   "+resultSplit[1] );

                IsOpen=true;// if the time open new

                LatLng from = new LatLng(currentLocation.latitude, currentLocation.longitude);
                LatLng to = new LatLng(lan, lon);

                double Distance = computeDistanceBetween(from, to); //32.065116,34.774285//initialLocation.latitude,initialLocation.longitude
                Distance = (Distance / 1000);// become from meter to km
                Distance = Math.floor(Distance * 100) / 100;//"#.##"
                String timeDelivery="15-25";
                if(Distance>1.0){//1 km
                    timeDelivery="30-35";
                }
                Log.e(TAG, "line 229  Distance =      "+Distance +"name res: "+name);
                if (Distance < DistanceLegal && Distance > 0.0 ) {//LASS THAN 4KM
                    //  Log.e(TAG, "result Distance  :" +( Distance));
                    mDataFirstFragmentTemp.add(new PropertyFirstFragment(city,timeDelivery, description, image, name, Blurhash, delivery_price,
                            String.valueOf(Distance), String.valueOf(1), IsOpen,tagsIdSearch,tagsIdAsLink));//feedback
                }
                // textView.append(image + "," + String.valueOf(lon) +","+String.valueOf(lan)+ "\n\n");
            }
            if(mDataFirstFragmentTemp.size()!=0){
                LocationOrderByNearToFar(mDataFirstFragmentTemp);

              //  DialogLocationTest();

            }else {
                // locationRetriever.setFitLocation(false);//try location  with other provider
                Log.e(TAG, " you not at the legal \n distance please change your location ");
                Toast.makeText(this.getActivity(),"you not at the legal \n distance please change your location ",Toast.LENGTH_LONG).show();
                progressBar_.setVisibility(View.INVISIBLE);
                if(mDataFirstFragment.size()==0){// the user not in right distance but the location got already to user
                    progressBar_.setVisibility(View.VISIBLE);
                    DialogLocation();
                    // DistanceLegal=3.5;
                    // BringTheJson(ResultJson);
                    Log.e(TAG, "line 330 mDataFirstFragment.size()==0  \n have to change location to max 2.0 km to restaurants" );


                }

            }

        } catch (JSONException e) {
            Log.e(TAG, "FirstFragment : field to Download json  ");
            e.printStackTrace();
        }
    }
    private void LocationOrderByNearToFar(ArrayList<PropertyFirstFragment> OrderBy){
        Log.e(TAG, "A" );
        Log.e(TAG, "order by near to dis   "+OrderBy.size());
        ArrayList<PropertyFirstFragment>  mData = new ArrayList<>(OrderBy);
        Log.e(TAG, " dis->   "+OrderBy.get(0).getmDistance());
        for (int i=0;i<OrderBy.size();i++) {

            for (int j = 0; j < OrderBy.size()-1; j++){
              //  Log.e(TAG, " boolean:  "+mData.get(OrderBy.size()).equals(mData.lastIndexOf(OrderBy.size())));
                if (Double.parseDouble(mData.get(j).getmDistance()) > Double.parseDouble(mData.get((j + 1)).getmDistance())) {

                    PropertyFirstFragment temp1 = mData.get(j);
                    PropertyFirstFragment temp2 = mData.get((j + 1));
                  //    mData.remove(j);
                    mData.remove(j);
                    mData.add(j, temp2);//because in index j value of km lower in index i
                    mData.remove(j+1);
                    mData.add((j + 1), temp1);//array this put inthis index


                    Log.e(TAG, "ok");
                }
             }

        }
        try {
            //  Thread.sleep(1000);
            Log.e(TAG, "B"+ mData.size());
            mDataFirstFragment=mData;
            mAdapter.loadNewData(mDataFirstFragment);//mAdapter reference to class and holder the data
            recyclerView.setAdapter(mAdapter);

            DataToShearch.resultAdapterList(currentLocation, mDataFirstFragment);
            progressBar_.setVisibility(View.INVISIBLE);
        } catch (Exception e) {
            e.printStackTrace();
        }
      //  return mDataFirstFragment;
    }



    //  ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED)
 /*   public void LocationCheck() {

        Log.e(TAG, "LocationCheck() line 342");
            locationRetriever = new LocationRetriever(context, this, location -> {
                setInitialLocation(new LatLng(location.getLatitude(), location.getLongitude()));
                //  input.setText(location.getLatitude() + "," + location.getLongitude());
            }, () -> {
                Log.w(TAG, "Failed to get location.");
                setInitialLocation(PRIME_MERIDIAN);
            });
      //  locationRetriever.start();

    }*/




    public void setInitialLocation(@NonNull LatLng latLng) {

        try {
           // initialLocation = new LatLng(0, 0);
            // Thread.sleep(500);
            initialLocation = latLng;
            if(initialLocation.latitude == 0.0 && initialLocation.longitude == 0.0){
                Log.e(TAG, " initialLocation  location is 0 !! , line 301.");

                // LocationCheck();
            }
          /*  if(ResultJson!=null&&mDataFirstFragment.size()==0){// maby the user not wase
                BringTheJson(ResultJson);// for save
            }*/

            if (currentLocation.longitude == 0 && currentLocation.latitude == 0) {//in the first time
                Log.e(TAG, " initialLocation first time location  line 265.");
                setCurrentLocation(initialLocation);

            } else {
                //else it currentLocation.longitude!=0
                //  Log.e(TAG, " setInitialLocation location line 248  " + initialLocation.latitude);
                if (initialLocation.latitude != 0.0 && initialLocation.longitude != 0.0) {// every time check if location change

                    if (CheckUserLocationChanged()) {//it not the first time or location user change more than
                        Log.e(TAG, " initialLocation location change.  ");
                        //    setCurrentLocation(initialLocation);
                        // currentLocation=initialLocation;

                    } else {
                        Log.e(TAG, " initialLocation location not change.  ");
                    }
                    // LocationCheck();
                }

            }// close else

        } catch(Exception e){
            e.printStackTrace();
        }

        // Intent intent =new Intent(getContext(),Search.class);

    }
    private void setCurrentLocation(LatLng location) {
        currentLocation = location;
        //   Log.e(TAG, " setCurrentLocation location." + currentLocation.latitude + "," + currentLocation.longitude);
    }


    private boolean CheckUserLocationChanged() {

        LatLng from = new LatLng(currentLocation.latitude, currentLocation.longitude);
        LatLng to = new LatLng(initialLocation.latitude, initialLocation.longitude);
        double Distance = computeDistanceBetween(from, to);
     //   Log.e(TAG, "line 378 , Location   =-------------------- " + Distance);
        Distance = (Distance / 100);// become from meter to 100 example 1000/100
        Distance = Math.floor(Distance * 100) / 100;//"#.##"
        Log.e(TAG, "line 380 , Location   = " + Distance);
        if (Distance > 0.1) {// if the user change location more than 100 meter
            progressBar_.setVisibility(View.VISIBLE);
            Log.e(TAG, "line 350 , Location Changed  = " + Distance);
            currentLocation=new LatLng(0, 0);

            currentLocation=to;   //initialLocation;
            if(ResultJson!=null) {
                BringTheJson(ResultJson);
                Toast.makeText(context,"the location changed in \n"+(Distance*100)+" meters",Toast.LENGTH_LONG).show();
                return true;
            }
        }

        //  return ((Distance > 1.0) ? true : false);//if the user changed location than more 200 meter bring again the data json
        return false;
    }

    private void DialogLocation(){
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this.getActivity(),R.style.AlertDialog);
        // AlertDialog.Builder   builder = new AlertDialog.Builder(this.getActivity());

        builder.setMessage(R.string.dialog_message_location).setTitle(R.string.dialog_title_location);

        // builder.setMessage(R.string.dialog_message_location).setCancelable(false);
        builder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                DistanceLegal=1000;
                dialog.dismiss();// if the location wrong open run for check
                BringTheJson(ResultJson);
            }
        });
        builder.setNegativeButton("no", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                progressBar_.setVisibility(View.INVISIBLE);
            }
        });
        // builder.show();
        android.app.AlertDialog alert = builder.create();
        //Setting the title manually
        // alert.setTitle("AlertDialogExample");
        alert.show();
    }

    private void DialogLocationTest(){
     /*   android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this.getActivity(),R.style.AlertDialog);//,R.style.AlertDialog
      //  builder.setMessage(R.string.dialog_message_location).setTitle(R.string.dialog_title_location);
        builder.setTitle("Dialog").setMessage("this Dialog for test").setCancelable(true).setNegativeButton("no", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        }).setPositiveButton("ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(context,"ok",Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        }).create().show();*/

        new MaterialAlertDialogBuilder(getActivity(),R.style.AlertDialog).setTitle(getResources().getString(R.string.go_to_order))
                .setMessage(getResources().getString(R.string.go_to_order)).setNeutralButton(getResources().getString(R.string.cancel), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(context,"ok",Toast.LENGTH_SHORT).show();
                dialog.cancel();
            }
        }).setNegativeButton(getResources().getString(R.string.mdecline), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(context,"ok",Toast.LENGTH_SHORT).show();
                dialog.cancel();
            }
        }).setPositiveButton(getResources().getString(R.string.accept), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        }).show();





    }
/////////////////////////---------------------------location

   public void LocationCallback(){
       Log.e(TAG, "  LocationCallback()  ----------------------------------------------------" );
     locationCallback = new LocationCallback() {
         @Override
         public void onLocationResult(LocationResult locationResult) {
             if (locationResult == null) {
                 Log.e(TAG, " onLocationResult wrong 77 line");
                 setInitialLocation(PRIME_MERIDIAN);
                 return;
             }
             for (Location location : locationResult.getLocations()) {
                 // Update UI with location data
                 //  successListener.onSuccess(location);
                 Log.e(TAG, "onSuccess line 352");
                 setInitialLocation(new LatLng(location.getLatitude(), location.getLongitude()));

                     //  successListener.onSuccess(location);

                 Log.e(TAG, " onLocationResult  ------------------------------" + location);
             }
         }
     };

 }




    private void LocationUpdates() {
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED ) {
           // AskPermission();
            Log.e(TAG, "LocationUpdates() no Permission ---------------------------------");
            return;
        }
        Log.e(TAG, "LocationUpdates()  locationCallback --------------------------------------");
        LocationCallback();
        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper());

    }


}