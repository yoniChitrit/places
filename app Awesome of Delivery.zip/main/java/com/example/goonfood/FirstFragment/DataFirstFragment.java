package com.example.goonfood.FirstFragment;

import android.location.Location;

import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;



public interface DataFirstFragment {

    void resultAdapterList(LatLng latLng, ArrayList< PropertyFirstFragment > mDataList);

}// to search


