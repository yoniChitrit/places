package com.example.goonfood;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import android.widget.LinearLayout;

import com.example.goonfood.FirstFragment.DataFirstFragment;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;


public class activity_splash extends AppCompatActivity {


    private final static int REQUEST_CHECK_SETTINGS = 10001;
    private LinearLayout mLinearLayoutOfButton_;
    private final static String TAG = "activity_splash";

   // private FusedLocationProviderClient fusedLocationClient;
   // private LocationCallback locationCallback;
    private LocationRequest locationRequest;

///////////
   // private static DataFirstFragment  LocationTOFirstFragment;


////////////

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);//, Manifest.permission.ACCESS_COARSE_LOCATION
        locationRequest = LocationRequest.create();

       // LocationCallback();

    }// ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION==PackageManager.PERMISSION_GRANTED


  /*  public static void  setContextFirstFragment(DataFirstFragment dataFirstFragment_){
       LocationTOFirstFragment=dataFirstFragment_;
        IsGetContext=true;

    }*/
 /*protected void LocationCallback(){

     locationCallback = new LocationCallback() {
         @Override
         public void onLocationResult(LocationResult locationResult) {
             if (locationResult == null) {
                 Log.e(TAG, " onLocationResult wrong 77 line");
                 if(IsGetContext) {
                     //failureListener.onFailure();
                     LocationTOFirstFragment.onFailure();
                 }
                 return;
             }
             for (Location location : locationResult.getLocations()) {
                 // Update UI with location data
                 //  successListener.onSuccess(location);

                 if(IsGetContext) {
                     //  successListener.onSuccess(location);
                     LocationTOFirstFragment.onSuccess(location);
                     Log.e(TAG, " onLocationResult 64 --------------------------" + location);
                 }else {
                     startActivity(new Intent(getBaseContext(), MainActivity.class));
                 }
                 Log.e(TAG, " onLocationResult 64 ------------------------------" + location);
             }
         }
     };

 }*/


    private void settingUser() {
        //   LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder();
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder().addLocationRequest(locationRequest);
        Log.e(TAG, " settingUser() builder: " + builder.build().toString());
        SettingsClient client = LocationServices.getSettingsClient(this);
        Task< LocationSettingsResponse > task = client.checkLocationSettings(builder.build());
        task.addOnSuccessListener(this, new OnSuccessListener< LocationSettingsResponse >() {
            @Override
            public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                // All location settings are satisfied. The client can initialize
                // location requests here.
                Log.e(TAG, "onSuccess: " + locationSettingsResponse.getLocationSettingsStates());
                try {
                    Thread.sleep(500);
                    startActivity(new Intent(getBaseContext(), MainActivity.class));
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        task.addOnFailureListener(this, new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                if (e instanceof ResolvableApiException) {
                    // Location settings are not satisfied, but this can be fixed
                    // by showing the user a dialog.
                    ActivityCompat.requestPermissions(activity_splash.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 101);

                    Log.e(TAG, "ResolvableApiException");
                    try {
                        // Show the dialog by calling startResolutionForResult(),
                        // and check the result in onActivityResult().
                        ResolvableApiException resolvable = (ResolvableApiException) e;
                        resolvable.startResolutionForResult(activity_splash.this, 1001);
                    } catch (IntentSender.SendIntentException sendEx) {
                        // Ignore the error.
                        sendEx.printStackTrace();
                        Log.e(TAG, "ERORR onFailure");
                    }
                }
            }
        });


    }


    @Override
    protected void onStop() {
        super.onStop();
       // fusedLocationClient.removeLocationUpdates(locationCallback);
       // IsGetContext=false;
        Log.e(TAG, "onStop()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e(TAG, "onDestroy()");
       // fusedLocationClient.removeLocationUpdates(locationCallback);
      //  IsGetContext=false;
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            AskPermission();
        }else {
            Log.e(TAG, "onStart()");
           settingUser();

        }


    }

  /*  private void LocationUpdates() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED ) {
        AskPermission();
            return;
        }
        Log.e(TAG, "LocationUpdates()");
        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper());

    }*/



    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        boolean permissionLocation=  ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)== PackageManager.PERMISSION_GRANTED;
        if (requestCode == REQUEST_CHECK_SETTINGS && permissionLocation) {
            Log.e(TAG, "onRequestPermissionsResult");
        //    settingUser();
            settingUser();


        }else {
            AskPermission();
        }
      //  super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }
public void AskPermission(){
    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION},REQUEST_CHECK_SETTINGS);
}


   /* private void lastLocation() {
        FusedLocationProviderClient fusedLocationClient_lastLocation;
        fusedLocationClient_lastLocation = LocationServices.getFusedLocationProviderClient(this);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {

        }
        //  Task<Location>
        fusedLocationClient_lastLocation.getLastLocation().addOnSuccessListener(this, new OnSuccessListener< Location >() {
            @Override
            public void onSuccess(Location location) {
                Log.e(TAG, " Unable to retrieve location." + location);
                //  successListener.onSuccess(location);
            }
        });
    }*/



}