package com.example.goonfood.Search;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.LinearLayout;
import android.widget.SearchView;
import android.widget.Toast;

import com.example.goonfood.MenuManagerItems.MainActivityMenu;
import com.example.goonfood.FirstFragment.DataFirstFragment;
import com.example.goonfood.FirstFragment.PropertyFirstFragment;
import com.example.goonfood.R;
import com.example.goonfood.RecyclerItemClickListener;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import static com.example.goonfood.FirstFragment.FirstFragment.setMyAdapterData;

/*
in the beginner check location and than bring the json
this Fragment get onDownloadComplete result and list of FirstFragment from MainActivity and than every time that user search name Restaurants the CheckLocationChanged()
if yes bring the json data again
*/
public class Search extends Fragment implements RecyclerItemClickListener.OnRecylerClickListener, DataFirstFragment
  {// implements LocationRetriever.SuccessListener,LocationRetriever.FailureListener{


    private static final String TAG = "Search";
    public static final String DATA_TRANSFER_SEARCH="DATA_TRANSFER_S";
  //  private static final LatLng PRIME_MERIDIAN = new LatLng(0, 0);//start with this

   // private static LatLng initialLocation;
    private  LatLng currentLocation = new LatLng(0, 0);
    @SuppressLint("StaticFieldLeak")
    private static Context context;
    private  View viewG;
    //private FirstFragment dataFristFragment ;

    private  MyAdapterSearch mAdapter;
    private  RecyclerView RecyclerViewSearch;

    private SearchView searchView;
    private ArrayList< PropertyFirstFragment > filteredList;
   private final static String[] TypeOfFood= new String[]{"burger","thai","pasta","sushi","pizza","sandwich","salad","kosher","kebab"};
   private String SearchClickButton;
   // hamburger thai pasta sushi


    private static ArrayList< PropertyFirstFragment > mDataListFromFirstFragment=new ArrayList<>();

    private static String ResultJson;
//private MaterialButtonToggleGroup MaterialButtonToggleGroup__;
private LinearLayout mLinearLayoutOfButton_;
  //  private RunForLocation runForLocation;

    public Search() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Log.e(TAG, "onCreateView");
        // Inflate the layout for this fragment

        return inflater.inflate(R.layout.search_layout, container, false);
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Log.e(TAG, "onViewCreated ");
        context = view.getContext().getApplicationContext();
        viewG=view;
        // Intent intent=  getIntent();
        searchView = (SearchView) view.findViewById(R.id.searchView);
        searchView.setQueryHint("Search");
        searchView.setImeOptions(EditorInfo.IME_ACTION_DONE);
        SearchRT();

       // MaterialButtonToggleGroup_=view.findViewById(R.id.MaterialGroup);
     //  mMediaRouteButton_= view.findViewById(R.id.mMediaRouteButton);
        RecyclerViewSearch = view.findViewById(R.id.RecyclerViewSearch);
        RecyclerViewSearch.setLayoutManager(new LinearLayoutManager(context));
         RecyclerViewSearch.addOnItemTouchListener(new RecyclerItemClickListener(context,RecyclerViewSearch,this));//event handler
        mAdapter = new MyAdapterSearch(context, new ArrayList<  >());
        RecyclerViewSearch.setAdapter(mAdapter);
       // mDataListFromFirstFragment =new ArrayList<>();


        CreateButtonSearch();

      //  CreateButtonSearch();
           // runForLocation=new RunForLocation();
           // runForLocation.run();
            Log.e(TAG, " onQueryTextChange inter to check location  ");



    }
    @Override
    public void onStart() {
        super.onStart();
        Log.e(TAG, "onStart() ");
        setMyAdapterData((DataFirstFragment) this);
        //  LocationCheck();
    }
 private void SearchRT(){

        if(SearchClickButton!=null){
            searchView.setQuery(SearchClickButton,true);
            SearchClickButton=null;
        }

     searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
         @SuppressLint("ShowToast")
         @Override
         public boolean onQueryTextSubmit(String query) {
             // Log.e(TAG, "Search"+query); mame.contains(query):searchView.clearFocus();
             return false;
         }
         @Override
         public boolean onQueryTextChange(String newText) {//if i input search box and changed , deleted char or add char than is going to method

             if(mDataListFromFirstFragment.size() == 0){//if data empty
                 Log.e(TAG, "  ResultJson is empty line 134 ");
                 return false;
             }
              filteredList = new ArrayList<>();
           //  filteredList.clear();
             if (newText.equals("")&&newText.isEmpty()) {
                 Log.e(TAG, "newText .equals empty  filteredList.clear()  "+filteredList.size());
                 //  Toast.makeText(context,"onQuery null :"+searchView.getQuery(),Toast.LENGTH_LONG).show();
                 mLinearLayoutOfButton_.setVisibility(View.VISIBLE);

               //  RecyclerViewSearch.clearFocus();
               //  mAdapter = new MyAdapterSearch(context, new ArrayList< >());
               //  RecyclerViewSearch.setAdapter(mAdapter);
                 filteredList.clear();
               //  CreateButtonSearch();
                // return false;
             } else {

                 String[] arrOfName;
                 String filterPattern = newText.toLowerCase().trim();
                 for (PropertyFirstFragment item : mDataListFromFirstFragment) {
                     arrOfName = item.getmNameRestaurnt().split(" ", 2);
                     Log.e(TAG,"item.getmNameRestaurnt().split: "+ arrOfName[0].toLowerCase()+"=="+filterPattern);
                     Log.e(TAG,"item.getmTagsSearch(): "+ item.getmTagsSearch()+"=="+SearchClickButton);

                     if (arrOfName[0].toLowerCase().contains(filterPattern)||item.getmTagsSearch().equals(filterPattern)) {
                       //  mLinearLayoutOfButton_.setVisibility(View.INVISIBLE);
                         Log.e(TAG,"inside  : ");

                      //   Log.e(TAG, "Search \n" + arrOfName[0]);
                         filteredList.add(new PropertyFirstFragment(item.getmCityRestaurants(),item.getmLocationTime(), item.getmDescription(), item.getmImageRestaurnt(),
                                 item.getmNameRestaurnt(), item.getmBlurhash(), item.getmDelivery_price(),
                                 String.valueOf(item.getmDistance()),item.getmFeedbackRestaurants(),item.ismIsOpenOrClose(),item.getmTagsSearch(),item.getmTagsLink()));

                     }
                 }
                 if(filteredList.size()==0){
                     Toast.makeText(context,"not found",Toast.LENGTH_SHORT).show();
                 }else {
                     Log.e(TAG, "filteredList: " + filteredList.size());
                     mLinearLayoutOfButton_.setVisibility(View.INVISIBLE);
                     mAdapter.loadNewData(filteredList);
                     RecyclerViewSearch.setAdapter(mAdapter);
                 }
                 // if(newText.length()>arrOfName[0].length()&&filteredList.size()==0){
                 //   Toast.makeText(context,"not found",Toast.LENGTH_SHORT);
                 //}
             }
             // Toast.makeText(context,""+newText,Toast.LENGTH_LONG).show();//every char input is it going here
             return false;
         }
     });
 }

    private void CreateButtonSearch(){

        int counter=0;
        LinearLayout.LayoutParams    params;
        for (int i=0;i<3;i++) {
            Log.e(TAG,""+i);
              //  params = new LinearLayout.LayoutParams((int) LinearLayout.LayoutParams.WRAP_CONTENT,(int) LinearLayout.LayoutParams.WRAP_CONTENT);
            params = new LinearLayout.LayoutParams((170) ,(100) );
            // params.setMargins(30,0,0,0);
                    mLinearLayoutOfButton_=viewG.findViewById(R.id.mLinearLayoutOfButton);
            MaterialButtonToggleGroup   MaterialButtonToggleGroup__ =new MaterialButtonToggleGroup(viewG.getContext());
            MaterialButtonToggleGroup__.setOrientation(MaterialButtonToggleGroup.VERTICAL);
            mLinearLayoutOfButton_.addView(MaterialButtonToggleGroup__);
            for(int j = 0; j < 3; j++,counter++) {
                MaterialButton mMediaRouteButton_ = new MaterialButton(viewG.getContext(),null,R.style.TextAppearance_MaterialComponents_Body1);//,null,R.style.groupButton
              //  mMediaRouteButton_.setStrokeWidth(5);
                mMediaRouteButton_.setText("name:"+i+"-"+j);
                if(TypeOfFood[counter]!=null) {
                    mMediaRouteButton_.setText(TypeOfFood[counter]);
                }
              //  params.leftMargin=20;
               // MaterialButtonToggleGroup__.addView(mMediaRouteButton_, j, params);

                MaterialButtonToggleGroup__.addView(mMediaRouteButton_,j,params);
                params.rightMargin=20;
                params.gravity=5;
                mMediaRouteButton_.setLayoutParams(params);

                ClickToSearchRT(mMediaRouteButton_);

            }


          /*  MaterialButtonToggleGroup__.addOnButtonCheckedListener(new MaterialButtonToggleGroup.OnButtonCheckedListener() {
                @Override
                public void onButtonChecked(MaterialButtonToggleGroup group, int checkedId, boolean isChecked) {
                    MaterialButton materialButton=(MaterialButton)group.findViewById(checkedId);
                    Toast.makeText(getContext(),materialButton.getText(),Toast.LENGTH_LONG).show();
                }
            });
            MaterialButtonToggleGroup__.clearDisappearingChildren();*/

        }


    }
    private void ClickToSearchRT(MaterialButton mMediaRouteButton_){
        mMediaRouteButton_.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                MaterialButton materialButton = (MaterialButton) v.findViewById(v.getId());
                Log.e(TAG, "length()->" + materialButton.length());
                SearchClickButton=materialButton.getText().toString();
                SearchRT();

            /*    ArrayList< PropertyFirstFragment > filteredList = new ArrayList<>();
                mAdapter = new MyAdapterSearch(context, new ArrayList<>());
                RecyclerViewSearch.setAdapter(mAdapter);
                MaterialButton materialButton = (MaterialButton) v.findViewById(v.getId());
                Log.e(TAG, "length()->" + materialButton.length());
                //   Toast.makeText(getContext(),materialButton.length(),Toast.LENGTH_LONG).show();
                for (PropertyFirstFragment item : mDataListFromFirstFragment) {
                    if (item.getmTagsSearch().equals(materialButton.getText().toString())) {
                        filteredList.add(new PropertyFirstFragment(item.getmCityRestaurants(), item.getmLocationTime(), item.getmDescription(), item.getmImageRestaurnt(),
                                item.getmNameRestaurnt(), item.getmBlurhash(), item.getmDelivery_price(),
                                String.valueOf(item.getmDistance()), item.getmFeedbackRestaurants(), item.ismIsOpenOrClose(), item.getmTagsSearch(), item.getmTagsLink()));
                    }

                }
                mAdapter.loadNewData(filteredList);
                RecyclerViewSearch.setAdapter(mAdapter);*/

            }
        });

    }

    @Override
    public void resultAdapterList(LatLng latLng, ArrayList< PropertyFirstFragment > mDataList) {
        mDataListFromFirstFragment.clear();
        currentLocation = latLng;// location from FirstFragment

       mDataListFromFirstFragment =new ArrayList<>(mDataList);
        Log.e(TAG, "resultAdapterList line 186: size = "+mDataListFromFirstFragment.size()+"currentLocation= "+currentLocation);

    }




   /* class RunForLocation implements Runnable{
      Handler  handler = new Handler();
         public RunForLocation(){}

        @Override
        public void run() {
            LocationCheck();
            Log.e(TAG, "run line 255 ---------------------------------------------");
            handler.postDelayed(this,(1000*30));
           // LocationCheck();
        }


    }
  */


    @Override
    public void OnItemClick(View view, int position) {
        Log.e(TAG, "OnItemClick  "+mAdapter.getmData(position).getmNameRestaurnt());
        if(mAdapter.getmData(position)!=null) {
            Intent intent = new Intent(getActivity(), MainActivityMenu.class);//RestaurantMenu.class
            intent.putExtra(DATA_TRANSFER_SEARCH, mAdapter.getmData(position));//REFERENCE FROM THE
            startActivity(intent);
        }else {
            Log.e(TAG, "filed bring data  ");
        }
    }

    @Override
    public void OnItemLongClick(View view, int position) {

    }






  /*  @Override
    public void onSuccess(@NonNull Location location) {
        Toast.makeText(context, "onSuccess "+location.getLatitude()+","+location.getLongitude() , Toast.LENGTH_LONG).show();
       Log.e(TAG, "Search : onSuccess  ");
    }

    @Override
    public void onFailure() {
        Toast.makeText(context, "onFailure() Location  ", Toast.LENGTH_LONG).show();
    }*/


        /*    if (newText.length()>1) {//&&newText.length()>3
                        int count=0;
                        for (DataRestaurants item : filteredList_check ) {
                            String[] arrOfName = item.getmName().split(" ", 2);
                            if(arrOfName[0].length()==newText.length()&&!arrOfName[0].equals(newText)){
                                //Toast.makeText(context, "remuve ", Toast.LENGTH_LONG).show();
                                mAdapter.removeAt(count);

                                if(filteredList.size()==count){
                                    Toast.makeText(context, "We did not find \n that name..", Toast.LENGTH_LONG).show();
                                }
                            }
                            count++;
                        }
                        filteredList_check.clear();
                        //Toast.makeText(context, "We did not find \n that name..", Toast.LENGTH_LONG).show();

                    }*/
}
