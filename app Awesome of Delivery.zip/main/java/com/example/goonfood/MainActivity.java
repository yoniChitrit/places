package com.example.goonfood;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;

import com.example.goonfood.FirstFragment.FirstFragment;
import com.example.goonfood.Profile.Profile;
import com.example.goonfood.Search.Search;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    private FragmentManager manager = getSupportFragmentManager();
    private Fragment mDelivery = new FirstFragment();
    private Fragment mSearch = new Search();
    private Fragment mProfile = new Profile();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.e(TAG, "mDelivery");
        manager.beginTransaction().add(R.id.main_Layout, mDelivery, "delivery").commitAllowingStateLoss();
        Log.e(TAG, "search");
        manager.beginTransaction().add(R.id.main_Layout, mSearch, "search").hide(mSearch).commitAllowingStateLoss();
        Log.e(TAG, "profile");
        manager.beginTransaction().add(R.id.main_Layout, mProfile, "profile").hide(mProfile).commitAllowingStateLoss();


        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @SuppressLint("NonConstantResourceId")
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                //   int id = item.getItemId();
                switch (item.getItemId()) {
                    case R.id.Delivery:
                        manager.beginTransaction().hide(mSearch).hide(mProfile).show(mDelivery).commitAllowingStateLoss();
                        break;
                    case R.id.Search:

                        manager.beginTransaction().hide(mDelivery).hide(mProfile).show(mSearch).commitAllowingStateLoss();
                        break;
                    case R.id.Profile:
                        manager.beginTransaction().hide(mDelivery).hide(mSearch).show(mProfile).commitAllowingStateLoss();
                        break;

                }
                return true;
            }
        });

    }
}