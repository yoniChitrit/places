package com.example.example.menu;

import androidx.recyclerview.widget.RecyclerView;

public class RecyclerItemClickListenerMenu extends RecyclerView.SimpleOnItemTouchListener{


}
